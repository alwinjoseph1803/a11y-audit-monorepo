(async function () {
  const root = document.getElementById("findings");
  try {
    const res = await fetch("/api/findings");
    if (!res.ok) throw new Error(res.status);
    const findings = await res.json();
    root.replaceChildren(...findings.map(render));
  } catch (err) {
    root.textContent = "Could not load findings.";
  }

  function render(f) {
    const el = document.createElement("article");
    el.setAttribute("aria-labelledby", f.id);
    const h = document.createElement("h2");
    h.id = f.id;
    h.textContent = f.title;
    const meta = document.createElement("p");
    const badge = document.createElement("span");
    badge.className = "badge";
    badge.textContent = f.priority;
    meta.append(badge, ` · ${f.category} · ${f.severity}`);
    const ev = document.createElement("p");
    ev.textContent = "Evidence: " + f.evidence;
    const fix = document.createElement("p");
    fix.textContent = "Fix: " + f.remediation;
    el.append(h, meta, ev, fix);
    return el;
  }
})();
