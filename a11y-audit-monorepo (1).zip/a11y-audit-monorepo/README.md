# Accessibility & Architecture Audit Monorepo

An audit of **TODO: site URL** (Lighthouse + keyboard-only pass), with five documented findings, plus a small app that publishes those findings.

## Architecture

```
client/   static UI (HTML/JS, no build step) – renders findings, itself built to be keyboard accessible
server/   Node HTTP server – serves client/public and exposes GET /api/findings
docs/     audit evidence (audit/), decisions (adr/) – the source of truth for findings
tests/    node:test integration tests that boot the real server
```

### Boundaries
| Layer | Owns | Must not |
|---|---|---|
| `docs/audit/findings.json` | Finding data (the contract) | Contain presentation |
| `server` | Reading/sorting findings, HTTP | Render HTML for findings |
| `client` | Rendering, focus/keyboard behavior | Read files or know the JSON path |
| `tests` | Verifying behavior via HTTP | Import internals other than `createServer` |

Dependency direction: `client → (HTTP) → server → docs`. Nothing points back.

## Local setup
Requires Node 20+.
```bash
git clone <this repo> && cd a11y-audit-monorepo
npm start        # http://localhost:3000
npm test
```

## First vertical slice: "View prioritized findings"
1. **Data:** `docs/audit/findings.json` (schema: id, title, category, severity, priority P0–P2, wcag, evidence, remediation)
2. **Server:** `server/src/findings.js` loads and sorts by priority; `index.js` serves `GET /api/findings`
3. **Client:** `client/public/app.js` fetches and renders each finding as a labelled `<article>`; skip link, visible focus, `aria-live` region
4. **Test:** `tests/findings.test.js` covers the endpoint contract and static serving

Next slices: filter by category, export to Markdown, link evidence screenshots.

## Doing the audit
Follow `docs/audit/AUDIT.md`, then replace the TODOs in `findings.json`.
