const test = require("node:test");
const assert = require("node:assert");
const { createServer } = require("../server/src/index");

test("GET /api/findings returns 5 findings sorted by priority", async () => {
  const server = createServer().listen(0);
  const { port } = server.address();
  try {
    const res = await fetch(`http://localhost:${port}/api/findings`);
    assert.strictEqual(res.status, 200);
    const data = await res.json();
    assert.strictEqual(data.length, 5);
    const order = data.map((f) => f.priority);
    assert.deepStrictEqual(order, [...order].sort());
    for (const f of data) {
      for (const k of ["id","title","category","severity","priority","evidence","remediation"])
        assert.ok(k in f, `missing ${k}`);
    }
  } finally {
    server.close();
  }
});

test("GET / serves the client", async () => {
  const server = createServer().listen(0);
  const { port } = server.address();
  try {
    const res = await fetch(`http://localhost:${port}/`);
    assert.strictEqual(res.status, 200);
    assert.match(await res.text(), /Audit Findings/);
  } finally {
    server.close();
  }
});
