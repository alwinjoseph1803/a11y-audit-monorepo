const fs = require("node:fs");
const path = require("node:path");

const FILE = path.join(__dirname, "..", "..", "docs", "audit", "findings.json");
const PRIORITY_ORDER = { P0: 0, P1: 1, P2: 2 };

function loadFindings() {
  const raw = JSON.parse(fs.readFileSync(FILE, "utf8"));
  return raw.findings.sort(
    (a, b) => PRIORITY_ORDER[a.priority] - PRIORITY_ORDER[b.priority]
  );
}

module.exports = { loadFindings };
