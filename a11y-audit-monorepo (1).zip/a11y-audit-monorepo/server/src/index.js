const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const { loadFindings } = require("./findings");

const PUBLIC_DIR = path.join(__dirname, "..", "..", "client", "public");
const TYPES = { ".html": "text/html", ".js": "text/javascript", ".css": "text/css" };

function createServer() {
  return http.createServer((req, res) => {
    if (req.url === "/api/findings") {
      res.writeHead(200, { "Content-Type": "application/json" });
      return res.end(JSON.stringify(loadFindings()));
    }
    const rel = req.url === "/" ? "index.html" : req.url.replace(/^\/+/, "");
    const file = path.normalize(path.join(PUBLIC_DIR, rel));
    if (!file.startsWith(PUBLIC_DIR) || !fs.existsSync(file)) {
      res.writeHead(404);
      return res.end("Not found");
    }
    res.writeHead(200, { "Content-Type": TYPES[path.extname(file)] || "text/plain" });
    fs.createReadStream(file).pipe(res);
  });
}

if (require.main === module) {
  const port = process.env.PORT || 3000;
  createServer().listen(port, () => console.log(`http://localhost:${port}`));
}

module.exports = { createServer };
