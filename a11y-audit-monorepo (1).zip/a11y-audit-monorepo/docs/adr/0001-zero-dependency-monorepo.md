# ADR 0001: Zero-dependency npm-workspaces monorepo
**Status:** accepted
Plain Node + static client keeps setup to `npm start`, makes boundaries obvious, and lets the audit content (not tooling) be the focus. Swap in Vite/Express later behind the same `/api` contract.
