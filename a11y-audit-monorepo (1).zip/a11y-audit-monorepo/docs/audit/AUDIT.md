# Audit Log

**Site:** TODO  **Date:** TODO  **Browser:** Chrome TODO  **Auditor:** TODO

## 1. Lighthouse
```bash
npx lighthouse https://YOUR-SITE --only-categories=accessibility,best-practices,performance \
  --output=html --output=json --output-path=docs/audit/lighthouse/report
```
Run mobile (default) and desktop (`--preset=desktop`). Record scores:

| Category | Mobile | Desktop |
|---|---|---|
| Accessibility | | |
| Best practices | | |
| Performance | | |

Commit a screenshot of the score summary to `docs/audit/lighthouse/` (reports are gitignored; scores and screenshots are the evidence).

## 2. Keyboard-only pass (unplug the mouse)
Check each; note the exact step and a screenshot for every failure.
- [ ] Tab reaches every interactive element, in a logical order
- [ ] Focus indicator always visible
- [ ] No keyboard traps (modals, menus, embeds)
- [ ] "Skip to content" link exists and works
- [ ] Menus/dropdowns operable with Enter/Space/Esc/arrows
- [ ] Forms: labels, error messages reachable and announced
- [ ] Visible text matches accessible names (check with devtools Accessibility tab)

## 3. Findings
Fill `findings.json` (five entries; rendered by the app in `client/`).
Priority: **P0** blocks task completion for keyboard/AT users; **P1** significant barrier or WCAG A/AA failure with workaround; **P2** polish / structural debt.
